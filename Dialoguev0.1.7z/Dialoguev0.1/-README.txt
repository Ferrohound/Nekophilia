First draft of dialogue following the path I�ve envisioned for the short story. 

Speakers of lines are as listed.

Lines listed in brackets [ ] are meant to still appear in the text box but are direct messages to the player, rather than a spoken line. 

I added in several �Investigation� files at the end which can be moved around to fit wherever we have the clues/ cues in the game. I  did this since I don�t know where exactly the level designers placed the corpses fighting over the lantern, the taxidermy etc. These will be expanded as I get a better idea of what�s in the levels. 

Some investigations don�t have a specific line reader. This is done so that either character can be the one �investigating� 

