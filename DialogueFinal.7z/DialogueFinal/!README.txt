First draft of dialogue using several scenarios/events that we've discussed will take place. 

Speakers of lines are as listed.

Lines listed in brackets [ ] are meant to still appear in the text box but are direct messages to the player, rather than a spoken line. 

Story Items are self explanitory and will say where they should go.

Codes will be read off the wall by Owen. The file listed for Neil has the spanish translations that will be on the wall.

Mechanic Introductions should go the first time a mechanic is introduced. (Lantern Oil, Crouching etc)

Investigations can be triggered by owen or Aimee approaching the item in question and pressing a button. 

Deaths should be played when the appropriate character dies. (Obviously)

Files that were relevant in earlier versions but not so much now can be found in the chopping block folder. 


- Brandon