First draft of dialogue using several scenarios/events that we've discussed will take place. 

Speakers of lines are as listed.

Lines listed in brackets [ ] are meant to still appear in the text box but are direct messages to the player, rather than a spoken line. 

I added in several �Investigation� files at the end which can be moved around to fit wherever we have the clues/ cues in the game. I  did this since I don�t know where exactly the level designers placed the corpses fighting over the lantern, the taxidermy etc. These will be expanded as I get a better idea of what�s in the levels. 

Some investigations don�t have a specific line reader. This is done so that either character can be the one �investigating� 

As the game changes (or inevitably gets compressed) I'll work on shortening/editing these.

Additionally, not all of these need be used. Once we program an event into the game (for ex. finding lantern fuel for the first time), the appropriate file can be played.

